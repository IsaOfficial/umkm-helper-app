# lofi
Low-fidelity UI mockups (HTML/CSS/JS) for UMKM Helper.

Commit label suggestion: "desain uiux"

Files:
- splash.html
- login.html
- register.html
- forgot.html
- dashboard.html
- product_list.html
- add_product.html
- order_list.html
- order_detail.html
- report.html
- profile.html
- settings.html
- styles.css

How to preview:
Open any *.html file in the folder with a browser (double click or use Live Server).

Suggested git commands to add these files with commit message:
```
git add lofi/
git commit -m "desain uiux"
git push origin main
```
